from flask import Blueprint, render_template, request, redirect, url_for, flash
import sqlite3

ticket_route = Blueprint('tickets', __name__)

# Mostrar eventos para possível compra de bilhetes
@ticket_route.route('/<int:id_event>/choose_session', methods=['GET'])
def choose_session(id_event):
    dbconnection = sqlite3.connect('database/eventos_bilhetes.db')
    cursor = dbconnection.cursor()
    cursor.execute('SELECT * FROM Events WHERE id = ?', (id_event,))
    event = cursor.fetchone()
    cursor.execute('SELECT * FROM Sessions WHERE id_event = ?', (id_event,))
    sessions = cursor.fetchall()
    dbconnection.close()
    return render_template('tickets/choose_session.html', event=event, sessions=sessions)

@ticket_route.route('/<int:id_session>/buy_from_seat_map', methods=['GET', 'POST'])
def buy_from_seat_map(id_session):
    conn = sqlite3.connect('database/eventos_bilhetes.db')
    cursor = conn.cursor()

    # Fetch Session and Event/Place Details
    cursor.execute("""
        SELECT s.id, s.session_date, s.base_price, e.title, p.name, p.id as id_place
        FROM Sessions s
        JOIN Events e ON s.id_event = e.id
        JOIN Places p ON e.id_place = p.id
        WHERE s.id = ?
    """, (id_session,))
    # usage: session['id'], session['session_date'], ...
    # row_factory is not set by default, so we map manually or use index
    row = cursor.fetchone()
    if not row:
        conn.close()
        return "Sessão não encontrada", 404
        
    session_data = {
        'id': row[0], 'session_date': row[1], 'base_price': row[2],
        'event_title': row[3], 'place_name': row[4], 'id_place': row[5]
    }
    
    # Check for logged in user
    from flask import session as flask_session
    user_id = flask_session.get('user_id')

    if request.method == 'POST':
        selected_seats_str = request.form.get('selected_seats') # "A1,A2"
        is_discounted = request.form.get('discount')
        
        if not selected_seats_str:
            conn.close()
            return "Nenhum lugar selecionado", 400

        selected_seats = selected_seats_str.split(',')
        base_price = session_data['base_price']
        final_price = base_price * 0.9 if is_discounted else base_price

        try:
            for seat_label in selected_seats:
                # Parse "A1" -> Row "A", Number "1" (simplified parser, assumes 1 letter row)
                # Better: Use regex or check logic. For now assuming Row is 1st char.
                # Actually, our JS sends "A1".
                import re
                match = re.match(r"([A-Z]+)([0-9]+)", seat_label)
                if match:
                    seat_row = match.group(1)
                    seat_number = int(match.group(2))
                    
                    # Insert Ticket
                    cursor.execute("""
                        INSERT INTO Tickets (id_session, id_user, seat_row, seat_number, paid_price) 
                        VALUES (?, ?, ?, ?, ?)
                    """, (id_session, user_id, seat_row, seat_number, final_price))
            
            conn.commit()
            flash('Compra efetuada com sucesso!', 'success')
            return redirect(url_for('home.home'))

        except Exception as e:
            conn.rollback()
            print(f"Erro na compra: {e}")
            flash('Erro ao processar compra.', 'error')
            return redirect(url_for('tickets.buy_from_seat_map', id_session=id_session))
        finally:
            conn.close()

    # GET: Prepare Map Data
    
    # 1. Fetch Sold Seats
    cursor.execute('SELECT seat_row, seat_number FROM Tickets WHERE id_session = ?', (id_session,))
    sold_seats = set((row[0], row[1]) for row in cursor.fetchall()) # {('A', 1), ('B', 2)}

    # 2. Fetch Seat Configuration
    cursor.execute('SELECT * FROM seats WHERE id_place = ?', (session_data['id_place'],))
    seats_config = cursor.fetchall()
    conn.close()

    processed_sectors = []
    
    for row_data in seats_config:
        sector_name = row_data[2]
        first_row_char = row_data[3]
        last_row_char = row_data[4]
        first_num = row_data[5]
        last_num = row_data[6]

        seats_list = []
        
        start_r_idx = ord(first_row_char) - 65
        end_r_idx = ord(last_row_char) - 65
        
        for r_idx in range(start_r_idx, end_r_idx + 1):
            row_char = chr(r_idx + 65)
            for n in range(first_num, last_num + 1):
                 status = 'taken' if (row_char, n) in sold_seats else 'available'
                 seats_list.append({
                    'label': f"{row_char}{n}",
                    'row': row_char, 
                    'number': n,
                    'x': 40 + (n - first_num) * 60,
                    'y': 40 + (r_idx - start_r_idx) * 60,
                    'width': 50, 'height': 50,
                    'status': status
                })

        width = 40 + (last_num - first_num + 1) * 60 + 20
        height = 40 + (end_r_idx - start_r_idx + 1) * 60 + 20

        processed_sectors.append({
            'name': sector_name, 
            'seats': seats_list,
            'width': width,
            'height': height
        })
        
    # Determine SVG size (approximate, max of all sectors)
    map_width = 800 
    map_height = 600

    return render_template('tickets/buy_from_seat_map.html', 
                           session=session_data, 
                           event={'title': session_data['event_title']},
                           place={'name': session_data['place_name']},
                           sectors=processed_sectors,
                           map_width=map_width, 
                           map_height=map_height,
                           session_user=user_id)

@ticket_route.route('/<int:id_session>/buy_from_capacity', methods=['GET', 'POST'])
def buy_from_capacity(id_session):
    conn = sqlite3.connect('database/eventos_bilhetes.db')
    cursor = conn.cursor()

    cursor.execute("""
        SELECT s.id, s.id_event, s.session_date, s.base_price, e.title, p.name, p.capacity 
        FROM Sessions s
        JOIN Events e ON s.id_event = e.id
        JOIN Places p ON e.id_place = p.id
        WHERE s.id = ?
    """, (id_session,))
    session = cursor.fetchone()

    cursor.execute('SELECT COUNT(*) FROM Tickets WHERE id_session = ?', (id_session,))
    sold_count = cursor.fetchone()
    available_seats = session[6] - sold_count[0]

    if request.method == 'POST':
        quantity = int(request.form.get('quantity'))
        is_discounted = request.form.get('discount')
        if quantity > 0 and quantity <= available_seats:
            base_price = session[3] 
            final_price = base_price * 0.9 if is_discounted else base_price
            for i in range(quantity):
                cursor.execute("""
                    INSERT INTO Tickets (id_session, id_seat, id_user, checkin, paid_price) 
                    VALUES (?, NULL, NULL, NULL, ?)
                """, (id_session, final_price))
            conn.commit()
            conn.close()
            return redirect('/tickets/invoice.html') 
        else:
            conn.close()
            return "Quantidade inválida ou lugares esgotados", 400

    conn.close()
    return render_template('tickets/buy_from_capacity.html', session=session, available_seats=available_seats)