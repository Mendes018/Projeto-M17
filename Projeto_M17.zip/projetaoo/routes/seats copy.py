from flask import Blueprint, render_template, request, redirect, url_for
import sqlite3

seat_route = Blueprint('seats', __name__)

# LISTAR TIPOS DE EVENTOS
@seat_route.route('/<int:id_place>', methods=['GET'])
def seat_list(id_place):
    dbconnection = sqlite3.connect('database/eventos_bilhetes.db')
    cursor = dbconnection.cursor()
    cursor.execute('SELECT * FROM Seats WHERE id_place = ?', (id_place,))
    seats = cursor.fetchall()
    cursor.execute('SELECT * FROM Places WHERE id = ?', (id_place,))
    place = cursor.fetchone()
    dbconnection.close()
    return render_template('seats/list.html', seats=seats, place=place)


# CRIAR TIPO DE EVENTO
@seat_route.route('/<int:id_place>/create', methods=['GET', 'POST'])
def seat_add(id_place):
    if request.method == 'POST':
        # 1. Obter dados do formulário
        sector = request.form.get('sector')
        first_row = request.form.get('first_row')
        last_row = request.form.get('last_row')
        first_number = request.form.get('first_number')
        last_number = request.form.get('last_number')
        
        # 2. Ligar à BD
        conn = sqlite3.connect('database/eventos_bilhetes.db')
        cursor = conn.cursor()
        try:

            # 3. Executar o comando SQL
            cursor.execute("""
                INSERT INTO seats (id_place, sector, first_row, last_row, first_number, last_number) 
                VALUES (?, ?, ?, ?, ?, ?)
            """, (id_place, sector, first_row, last_row, first_number, last_number))

            # 4. Gravar as alterações
            conn.commit() 
            print("Lugar gravado com sucesso!")

        except Exception as e:
            print(f"Erro ao inserir: {e}")
            conn.rollback() # Cancela se houver erro

        finally:
            # 5. Fechar a ligação à BD
            conn.close()

        # 6. Redirecionar para a lista de eventos
        return redirect(url_for('seats.seat_list', id_place=id_place))
        
    return render_template('seats/create.html', id_place=id_place)
    
@seat_route.route('/edit/<int:id>', methods=['GET', 'POST'])
def seat_update(id):
    dbconnection = sqlite3.connect('database/eventos_bilhetes.db')
    cursor = dbconnection.cursor()
    cursor.execute('SELECT * FROM seats WHERE id = ?', (id,))
    seat = cursor.fetchone()
    id_place = seat[1]
    dbconnection.close()

    if request.method == 'POST':
        # 1. Obter dados do formulário
        sector = request.form.get('sector')
        first_row = request.form.get('first_row')
        last_row = request.form.get('last_row')
        first_number = request.form.get('first_number')
        last_number = request.form.get('last_number')

        # 2. Ligar à BD
        conn = sqlite3.connect('database/eventos_bilhetes.db')
        cursor = conn.cursor()
        try:
            # 3. Executar o comando SQL
            cursor.execute("""
                UPDATE seats SET sector = ?, first_row = ?, last_row = ?, first_number = ?, last_number = ? WHERE id = ?
            """, (sector, first_row, last_row, first_number, last_number, id))

            # 4. Gravar as alterações
            conn.commit() 
            print("Lugar atualizado com sucesso!")

        except Exception as e:
            print(f"Erro ao atualizar: {e}")
            conn.rollback() # Cancela se houver erro
        finally:
            # 5. Fechar a ligação à BD
            conn.close()

        # 6. Redirecionar para a lista de eventos
        return redirect(url_for('seats.seat_list', id_place=id_place))

    return render_template('seats/edit.html', seat=seat)

@seat_route.route('/delete/<int:id>', methods=['GET', 'POST'])
def seat_delete(id):
    dbconnection = sqlite3.connect('database/eventos_bilhetes.db')
    cursor = dbconnection.cursor()
    cursor.execute('SELECT id_place FROM seats WHERE id = ?', (id,))
    id_place = cursor.fetchone()
    id_place=id_place[0]
    cursor.execute('DELETE FROM seats WHERE id = ?', (id,))
    dbconnection.commit()
    dbconnection.close()
    return redirect(url_for('seats.seat_list', id_place=id_place))


@seat_route.route('/details/<int:id>', methods=['GET'])
def seat_detail(id):
    dbconnection = sqlite3.connect('database/eventos_bilhetes.db')
    cursor = dbconnection.cursor()
    cursor.execute('SELECT id_place FROM seats WHERE id = ?', (id,))
    id_place = cursor.fetchone()
    cursor.execute('SELECT * FROM seats WHERE id = ?', (id,))
    seat = cursor.fetchone()
    dbconnection.close()
    return render_template('seats/details.html', id_place=id_place, seat=seat)

@seat_route.route('/<int:id_place>/map', methods=['GET'])
def seat_map(id_place):
    conn = sqlite3.connect('database/eventos_bilhetes.db')
    cursor = conn.cursor()
    
    cursor.execute('SELECT name FROM Places WHERE id = ?', (id_place,))
    place_result = cursor.fetchone()
    place_name = place_result[0]

    cursor.execute('SELECT * FROM seats WHERE id_place = ?', (id_place,))
    seats_data = cursor.fetchall()
    conn.close()

    sectors = {}
    
    for seat_range in seats_data:
        sector_name = seat_range[2]
        
        if not sector_name:
            continue

        if sector_name not in sectors:
            sectors[sector_name] = {
                'name': sector_name,
                'min_row_idx': float('inf'),
                'max_row_idx': float('-inf'),
                'min_num': float('inf'),
                'max_num': float('-inf'),
                'seat_list': []
            }
            
        try:
            first_row_char = seat_range[3]
            last_row_char = seat_range[4]
            first_num = int(seat_range[5])
            last_num = int(seat_range[6])
            
            start_row_idx = ord(first_row_char.upper()) - 65
            end_row_idx = ord(last_row_char.upper()) - 65
        except (ValueError, TypeError, AttributeError):
            continue
        
        if start_row_idx > end_row_idx:
            start_row_idx, end_row_idx = end_row_idx, start_row_idx
        
        if first_num > last_num:
            first_num, last_num = last_num, first_num
            
        s = sectors[sector_name]
        s['min_row_idx'] = min(s['min_row_idx'], start_row_idx)
        s['max_row_idx'] = max(s['max_row_idx'], end_row_idx)
        s['min_num'] = min(s['min_num'], first_num)
        s['max_num'] = max(s['max_num'], last_num)
        
        # Generate individual seats
        for r_idx in range(start_row_idx, end_row_idx + 1):
            for n in range(first_num, last_num + 1):
                row_char = chr(r_idx + 65)
                # Check for duplicates? For now we just add them.
                s['seat_list'].append({
                    'row': row_char,
                    'number': n,
                    'row_idx': r_idx,
                    'col_idx': n
                })

    # Prepare final structure for template
    processed_sectors = []
    sorted_sector_names = sorted(sectors.keys())
    
    SEAT_SIZE = 50  # Increased size to fit text "A15"
    GAP = 10
    MARGIN_TOP = 40
    MARGIN_LEFT = 40
    MARGIN_RIGHT = 20
    MARGIN_BOTTOM = 20
    
    for name in sorted_sector_names:
        s = sectors[name]
        
        if not s['seat_list']:
            continue
            
        # Normalize grid to start at 0,0 relative to the sector's top-left
        row_offset = s['min_row_idx']
        col_offset = s['min_num']
        
        # Width/Heigth in units (seats)
        width_units = (s['max_num'] - s['min_num']) + 1
        height_units = (s['max_row_idx'] - s['min_row_idx']) + 1
        
        # SVG specific dimensions
        svg_width = MARGIN_LEFT + width_units * (SEAT_SIZE + GAP) - GAP + MARGIN_RIGHT
        svg_height = MARGIN_TOP + height_units * (SEAT_SIZE + GAP) - GAP + MARGIN_BOTTOM
        
        final_seats = []
        
        # Sets to track which rows/cols exist to create labels
        existing_rows = set()
        existing_cols = set()

        for seat in s['seat_list']:
            # x is based on seat number (columns)
            # y is based on row index (rows)
            x = MARGIN_LEFT + (seat['number'] - col_offset) * (SEAT_SIZE + GAP)
            y = MARGIN_TOP + (seat['row_idx'] - row_offset) * (SEAT_SIZE + GAP)
            
            existing_rows.add((seat['row'], seat['row_idx']))
            existing_cols.add((seat['number'], seat['number'])) # label, value (same for number)

            final_seats.append({
                'label': f"{seat['row']}{seat['number']}",
                'row': seat['row'],
                'number': seat['number'],
                'x': x,
                'y': y,
                'width': SEAT_SIZE,
                'height': SEAT_SIZE
            })
            
        # Generate Label Objects
        row_labels = []
        for r_char, r_idx in sorted(list(existing_rows), key=lambda x: x[1]):
             # Centered vertically relative to the seat row
             y = MARGIN_TOP + (r_idx - row_offset) * (SEAT_SIZE + GAP) + (SEAT_SIZE / 2)
             row_labels.append({'label': r_char, 'x': 10, 'y': y})

        col_labels = []
        for c_num, c_val in sorted(list(existing_cols), key=lambda x: x[1]):
             # Centered horizontally relative to the seat col
             x = MARGIN_LEFT + (c_val - col_offset) * (SEAT_SIZE + GAP) + (SEAT_SIZE / 2)
             col_labels.append({'label': str(c_num), 'x': x, 'y': 25})

        processed_sectors.append({
            'name': name,
            'width': svg_width,
            'height': svg_height,
            'seats': final_seats,
            'row_labels': row_labels,
            'col_labels': col_labels
        })

    return render_template('seats/map.html', place_name=place_name, sectors=processed_sectors, id_place=id_place)
